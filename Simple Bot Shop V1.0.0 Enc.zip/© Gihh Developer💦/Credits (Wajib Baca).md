⟣━»I N F O R M A S I«━⟢
👤Developer : ⏤͟͟͞͞Gihh Hosting ㄆ
💻Bot Name : Simple Bot Shop
📱WhatsApp 1 : +62882015082351
📱WhatsApp 2 : +6282173284892
💡Telegram : t.me/GihhNotSepuhh


⟣━»THANKS TO«━⟢
- Allah Swt
- Muhammad Saw
- Orang Tua
- My Friends
- Penyedia Api [PutraStore]
- Penyedia Module [KaiiOfficial]
- Penyedia Base [SanzHosting]
- NexusTzy [Support]
- DimzXiter [Support]

Dilarang Keras Untuk Menjual Script Ini Tanpa Sepengetahuan Developer, Jika Ketahuan Ada Seseorang Yang Berani Menjual Script Ini Maka Saya Dan Team Akan Melakukan Tindakan Tegas.